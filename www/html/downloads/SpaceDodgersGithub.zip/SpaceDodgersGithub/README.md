# Space Dodgers v1.2
Developed in Python's Pygame library. Inspired by the music game: The Impossible Game

Requirements:
Windows OS and python+pygame installed.

How to execute:
Open the executable file
